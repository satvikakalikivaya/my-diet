import { Recipe } from '../types';

export const andhraRecipes: Recipe[] = [
  // Breakfast
  {
    id: 'pesarattu',
    name: 'Healthy Pesarattu',
    nameInTelugu: 'పెసరట్టు',
    category: 'breakfast',
    calories: 180,
    protein: 12,
    carbs: 25,
    fat: 4,
    fiber: 8,
    ingredients: [
      '1 cup whole green moong dal',
      '2 green chilies',
      '1 inch ginger',
      'Few curry leaves',
      '1/4 tsp turmeric',
      'Salt to taste',
      '1 tsp oil for cooking'
    ],
    instructions: [
      'Soak moong dal for 4-6 hours',
      'Grind with green chilies, ginger to coarse paste',
      'Add curry leaves, turmeric, salt',
      'Make thin dosas on non-stick pan with minimal oil',
      'Serve hot with coconut chutney'
    ],
    prepTime: 15,
    cookTime: 20,
    servings: 2,
    isHealthyVersion: true,
    affordabilityScore: 5,
    weightLossFriendly: true
  },
  {
    id: 'ragi-idli',
    name: 'Ragi Idli',
    nameInTelugu: 'రాగి ఇడ్లీ',
    category: 'breakfast',
    calories: 120,
    protein: 4,
    carbs: 20,
    fat: 2,
    fiber: 3,
    ingredients: [
      '1 cup ragi flour',
      '1/2 cup urad dal',
      '1/4 cup poha',
      'Salt to taste',
      '1 tsp eno fruit salt'
    ],
    instructions: [
      'Soak urad dal and poha for 4 hours',
      'Grind to smooth batter',
      'Mix ragi flour with water to make smooth batter',
      'Combine both batters, add salt',
      'Add eno before steaming',
      'Steam in idli plates for 12-15 minutes'
    ],
    prepTime: 20,
    cookTime: 15,
    servings: 4,
    isHealthyVersion: true,
    affordabilityScore: 4,
    weightLossFriendly: true
  },

  // Lunch
  {
    id: 'sambar-rice',
    name: 'Protein-Rich Sambar Rice',
    nameInTelugu: 'సాంబార్ అన్నం',
    category: 'lunch',
    calories: 280,
    protein: 15,
    carbs: 45,
    fat: 6,
    fiber: 12,
    ingredients: [
      '1/2 cup brown rice',
      '1/4 cup toor dal',
      '1/2 cup mixed vegetables (drumstick, okra, tomato)',
      '1 tbsp sambar powder',
      '1/2 tsp turmeric',
      '1 tsp tamarind paste',
      '1 tsp oil',
      'Curry leaves, mustard seeds'
    ],
    instructions: [
      'Cook brown rice and toor dal separately',
      'Prepare vegetables with turmeric',
      'Make tempering with oil, mustard seeds, curry leaves',
      'Add sambar powder, tamarind paste',
      'Combine all ingredients and simmer',
      'Serve hot'
    ],
    prepTime: 15,
    cookTime: 30,
    servings: 2,
    isHealthyVersion: true,
    affordabilityScore: 5,
    weightLossFriendly: true
  },
  {
    id: 'quinoa-pulihora',
    name: 'Quinoa Pulihora',
    nameInTelugu: 'క్వినోవా పులిహోర',
    category: 'lunch',
    calories: 220,
    protein: 8,
    carbs: 32,
    fat: 7,
    fiber: 5,
    ingredients: [
      '1 cup cooked quinoa',
      '2 tbsp tamarind paste',
      '1 tsp turmeric',
      '2 green chilies',
      '1 tbsp peanuts',
      '1 tsp mustard seeds',
      'Curry leaves',
      '2 tsp oil'
    ],
    instructions: [
      'Cook quinoa and let it cool',
      'Make tempering with oil, mustard seeds',
      'Add peanuts, green chilies, curry leaves',
      'Add tamarind paste, turmeric',
      'Mix with quinoa gently',
      'Garnish with coriander'
    ],
    prepTime: 20,
    cookTime: 15,
    servings: 2,
    isHealthyVersion: true,
    affordabilityScore: 3,
    weightLossFriendly: true
  },

  // Dinner
  {
    id: 'moong-dal-khichdi',
    name: 'Moong Dal Khichdi',
    nameInTelugu: 'పచ్చి పప్పు ఖిచ్డీ',
    category: 'dinner',
    calories: 200,
    protein: 12,
    carbs: 30,
    fat: 4,
    fiber: 8,
    ingredients: [
      '1/2 cup brown rice',
      '1/4 cup moong dal',
      '1/2 cup mixed vegetables',
      '1 tsp ghee',
      '1/2 tsp turmeric',
      '1 tsp cumin seeds',
      'Ginger, green chilies',
      'Salt to taste'
    ],
    instructions: [
      'Wash rice and dal together',
      'Add vegetables, turmeric, salt',
      'Cook in pressure cooker with 3 cups water',
      'Make tempering with ghee, cumin seeds',
      'Add ginger, green chilies',
      'Pour over khichdi and mix'
    ],
    prepTime: 10,
    cookTime: 20,
    servings: 2,
    isHealthyVersion: true,
    affordabilityScore: 5,
    weightLossFriendly: true
  },
  {
    id: 'vegetable-kootu',
    name: 'Mixed Vegetable Kootu',
    nameInTelugu: 'కూరగాయల కూటు',
    category: 'dinner',
    calories: 150,
    protein: 8,
    carbs: 18,
    fat: 5,
    fiber: 7,
    ingredients: [
      '1 cup mixed vegetables (bottle gourd, beans, carrot)',
      '1/4 cup chana dal',
      '1/2 cup coconut gratings',
      '2 green chilies',
      '1/2 tsp turmeric',
      '1 tsp oil',
      'Mustard seeds, curry leaves'
    ],
    instructions: [
      'Cook chana dal until soft',
      'Cook vegetables with turmeric and salt',
      'Grind coconut with green chilies',
      'Mix dal, vegetables, and coconut paste',
      'Make tempering and add to kootu',
      'Simmer for 5 minutes'
    ],
    prepTime: 15,
    cookTime: 25,
    servings: 3,
    isHealthyVersion: true,
    affordabilityScore: 4,
    weightLossFriendly: true
  },

  // Snacks
  {
    id: 'steamed-sundal',
    name: 'Steamed Chana Sundal',
    nameInTelugu: 'ఆవిరి చెణాల సుండల్',
    category: 'snack',
    calories: 120,
    protein: 8,
    carbs: 18,
    fat: 2,
    fiber: 6,
    ingredients: [
      '1/2 cup black chana (soaked overnight)',
      '1 green chili',
      '1/4 tsp turmeric',
      '1 tsp oil',
      'Mustard seeds, curry leaves',
      'Fresh coconut gratings',
      'Salt to taste'
    ],
    instructions: [
      'Steam soaked chana until soft',
      'Make tempering with oil, mustard seeds',
      'Add green chili, curry leaves',
      'Add steamed chana, turmeric, salt',
      'Garnish with fresh coconut',
      'Serve warm'
    ],
    prepTime: 10,
    cookTime: 25,
    servings: 2,
    isHealthyVersion: true,
    affordabilityScore: 5,
    weightLossFriendly: true
  }
];