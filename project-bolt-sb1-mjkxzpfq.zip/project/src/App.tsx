import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { MealPlan } from './components/MealPlan';
import { Recipes } from './components/Recipes';
import { UserProfile } from './types';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const savedProfile = localStorage.getItem('andhraUserProfile');
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile));
    }
  }, []);

  const handleProfileUpdate = (profile: UserProfile) => {
    setUserProfile(profile);
    localStorage.setItem('andhraUserProfile', JSON.stringify(profile));
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard userProfile={userProfile} onProfileUpdate={handleProfileUpdate} />;
      case 'meal-plan':
        return <MealPlan userProfile={userProfile} />;
      case 'recipes':
        return <Recipes />;
      default:
        return <Dashboard userProfile={userProfile} onProfileUpdate={handleProfileUpdate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-yellow-50">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderActiveTab()}
      </main>
    </div>
  );
}

export default App;