import React, { useState } from 'react';
import { Calendar, Plus, RotateCcw } from 'lucide-react';
import { Recipe, MealPlan as MealPlanType, UserProfile } from '../types';
import { andhraRecipes } from '../data/recipes';
import { RecipeCard } from './RecipeCard';

interface MealPlanProps {
  userProfile: UserProfile | null;
}

export const MealPlan: React.FC<MealPlanProps> = ({ userProfile }) => {
  const [currentWeek, setCurrentWeek] = useState(0);
  const [weeklyPlan, setWeeklyPlan] = useState<MealPlanType[]>([]);

  const getDateString = (dayOffset: number) => {
    const date = new Date();
    date.setDate(date.getDate() + currentWeek * 7 + dayOffset);
    return date.toISOString().split('T')[0];
  };

  const generateMealPlan = () => {
    const newWeekPlan: MealPlanType[] = [];
    
    for (let day = 0; day < 7; day++) {
      const breakfast = andhraRecipes.filter(r => r.category === 'breakfast')[Math.floor(Math.random() * andhraRecipes.filter(r => r.category === 'breakfast').length)];
      const lunch = andhraRecipes.filter(r => r.category === 'lunch')[Math.floor(Math.random() * andhraRecipes.filter(r => r.category === 'lunch').length)];
      const dinner = andhraRecipes.filter(r => r.category === 'dinner')[Math.floor(Math.random() * andhraRecipes.filter(r => r.category === 'dinner').length)];
      const snacks = [andhraRecipes.filter(r => r.category === 'snack')[Math.floor(Math.random() * andhraRecipes.filter(r => r.category === 'snack').length)]];

      const totalCalories = breakfast.calories + lunch.calories + dinner.calories + snacks.reduce((sum, snack) => sum + snack.calories, 0);
      const totalProtein = breakfast.protein + lunch.protein + dinner.protein + snacks.reduce((sum, snack) => sum + snack.protein, 0);
      const totalCarbs = breakfast.carbs + lunch.carbs + dinner.carbs + snacks.reduce((sum, snack) => sum + snack.carbs, 0);
      const totalFat = breakfast.fat + lunch.fat + dinner.fat + snacks.reduce((sum, snack) => sum + snack.fat, 0);

      newWeekPlan.push({
        id: `plan-${day}`,
        date: getDateString(day),
        breakfast,
        lunch,
        dinner,
        snacks,
        totalCalories,
        totalProtein,
        totalCarbs,
        totalFat
      });
    }
    
    setWeeklyPlan(newWeekPlan);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const getDayCalorieStatus = (totalCalories: number) => {
    if (!userProfile) return 'text-gray-600';
    const target = userProfile.dailyCalorieGoal;
    const diff = Math.abs(totalCalories - target);
    const percentage = (diff / target) * 100;
    
    if (percentage <= 10) return 'text-green-600';
    if (percentage <= 20) return 'text-orange-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
          <div>
            <h2 className="text-2xl font-bold text-gray-800 flex items-center space-x-2">
              <Calendar className="h-6 w-6 text-orange-500" />
              <span>Weekly Meal Plan</span>
            </h2>
            <p className="text-gray-600 mt-1">
              Balanced Andhra vegetarian meals for healthy weight loss
            </p>
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={() => setCurrentWeek(currentWeek - 1)}
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200"
            >
              <span>← Previous Week</span>
            </button>
            
            <button
              onClick={generateMealPlan}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg hover:from-orange-600 hover:to-red-600 transition duration-200"
            >
              <RotateCcw className="h-4 w-4" />
              <span>Generate Plan</span>
            </button>
            
            <button
              onClick={() => setCurrentWeek(currentWeek + 1)}
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200"
            >
              <span>Next Week →</span>
            </button>
          </div>
        </div>
      </div>

      {weeklyPlan.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <div className="mb-6">
            <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No Meal Plan Yet</h3>
            <p className="text-gray-500">Generate your personalized weekly meal plan to get started!</p>
          </div>
          
          <button
            onClick={generateMealPlan}
            className="bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold py-3 px-8 rounded-lg hover:from-orange-600 hover:to-red-600 transition duration-200"
          >
            <Plus className="h-5 w-5 inline mr-2" />
            Generate My Meal Plan
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {weeklyPlan.map((dayPlan, index) => (
            <div key={dayPlan.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-orange-100 to-red-100 p-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
                  <h3 className="text-lg font-semibold text-gray-800">
                    {formatDate(dayPlan.date)}
                  </h3>
                  <div className="flex space-x-4 mt-2 sm:mt-0">
                    <span className={`font-semibold ${getDayCalorieStatus(dayPlan.totalCalories)}`}>
                      {dayPlan.totalCalories} cal
                    </span>
                    {userProfile && (
                      <span className="text-gray-600">
                        Target: {userProfile.dailyCalorieGoal} cal
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Breakfast</h4>
                    <div className="scale-95">
                      <RecipeCard recipe={dayPlan.breakfast} />
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Lunch</h4>
                    <div className="scale-95">
                      <RecipeCard recipe={dayPlan.lunch} />
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Dinner</h4>
                    <div className="scale-95">
                      <RecipeCard recipe={dayPlan.dinner} />
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">Snacks</h4>
                    {dayPlan.snacks.map((snack, snackIndex) => (
                      <div key={snackIndex} className="scale-95 mb-3">
                        <RecipeCard recipe={snack} />
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-orange-600">{dayPlan.totalCalories}</p>
                      <p className="text-sm text-gray-600">Total Calories</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-600">{dayPlan.totalProtein.toFixed(1)}g</p>
                      <p className="text-sm text-gray-600">Protein</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">{dayPlan.totalCarbs.toFixed(1)}g</p>
                      <p className="text-sm text-gray-600">Carbs</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-purple-600">{dayPlan.totalFat.toFixed(1)}g</p>
                      <p className="text-sm text-gray-600">Fat</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};