import React from 'react';
import { Clock, Users, DollarSign, Heart, Zap } from 'lucide-react';
import { Recipe } from '../types';

interface RecipeCardProps {
  recipe: Recipe;
  onSelect?: (recipe: Recipe) => void;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onSelect }) => {
  const affordabilityText = ['Very Expensive', 'Expensive', 'Moderate', 'Affordable', 'Very Affordable'];
  
  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">{recipe.name}</h3>
            {recipe.nameInTelugu && (
              <p className="text-sm text-orange-600 font-medium">{recipe.nameInTelugu}</p>
            )}
          </div>
          <div className="flex space-x-1">
            {recipe.weightLossFriendly && (
              <span className="bg-green-100 text-green-800 p-1 rounded-full">
                <Heart className="h-4 w-4" />
              </span>
            )}
            {recipe.isHealthyVersion && (
              <span className="bg-blue-100 text-blue-800 p-1 rounded-full">
                <Zap className="h-4 w-4" />
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Clock className="h-4 w-4" />
            <span>{recipe.prepTime + recipe.cookTime} mins</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Users className="h-4 w-4" />
            <span>{recipe.servings} servings</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <DollarSign className="h-4 w-4" />
            <span>{affordabilityText[recipe.affordabilityScore - 1]}</span>
          </div>
          <div className="text-sm text-gray-600">
            <span className="font-medium">{recipe.calories}</span> cal
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 mb-4">
          <div className="text-center">
            <p className="text-xs text-gray-500">Protein</p>
            <p className="font-semibold text-green-600">{recipe.protein}g</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Carbs</p>
            <p className="font-semibold text-blue-600">{recipe.carbs}g</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Fat</p>
            <p className="font-semibold text-orange-600">{recipe.fat}g</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Fiber</p>
            <p className="font-semibold text-purple-600">{recipe.fiber}g</p>
          </div>
        </div>

        <div className="mb-4">
          <h4 className="font-medium text-gray-800 mb-2">Key Ingredients:</h4>
          <p className="text-sm text-gray-600 line-clamp-2">
            {recipe.ingredients.slice(0, 3).join(', ')}
            {recipe.ingredients.length > 3 && '...'}
          </p>
        </div>

        {onSelect && (
          <button
            onClick={() => onSelect(recipe)}
            className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white font-medium py-2 px-4 rounded-lg hover:from-orange-600 hover:to-red-600 transition duration-200"
          >
            View Recipe
          </button>
        )}
      </div>
    </div>
  );
};