import React, { useState } from 'react';
import { Scale, Target, TrendingDown, Calendar, Activity } from 'lucide-react';
import { UserProfile, WeightEntry } from '../types';

interface DashboardProps {
  userProfile: UserProfile | null;
  onProfileUpdate: (profile: UserProfile) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ userProfile, onProfileUpdate }) => {
  const [showProfileForm, setShowProfileForm] = useState(!userProfile);
  const [formData, setFormData] = useState<Partial<UserProfile>>(
    userProfile || {
      name: '',
      age: 25,
      weight: 70,
      height: 165,
      targetWeight: 65,
      activityLevel: 'moderate'
    }
  );

  const calculateBMI = (weight: number, height: number) => {
    return (weight / ((height / 100) ** 2)).toFixed(1);
  };

  const calculateDailyCalories = (profile: UserProfile) => {
    // Mifflin-St Jeor Equation for women (assuming)
    const bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age - 161;
    const activityMultipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9
    };
    return Math.round(bmr * activityMultipliers[profile.activityLevel] - 500); // 500 cal deficit for weight loss
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const profile: UserProfile = {
      ...formData as UserProfile,
      dailyCalorieGoal: calculateDailyCalories(formData as UserProfile)
    };
    onProfileUpdate(profile);
    setShowProfileForm(false);
  };

  const bmi = userProfile ? calculateBMI(userProfile.weight, userProfile.height) : 0;
  const weightToLose = userProfile ? userProfile.weight - userProfile.targetWeight : 0;

  if (showProfileForm) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            Set Up Your Profile
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Age
                </label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Current Weight (kg)
                </label>
                <input
                  type="number"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: parseFloat(e.target.value) })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  step="0.1"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Height (cm)
                </label>
                <input
                  type="number"
                  value={formData.height}
                  onChange={(e) => setFormData({ ...formData, height: parseFloat(e.target.value) })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target Weight (kg)
                </label>
                <input
                  type="number"
                  value={formData.targetWeight}
                  onChange={(e) => setFormData({ ...formData, targetWeight: parseFloat(e.target.value) })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  step="0.1"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Activity Level
                </label>
                <select
                  value={formData.activityLevel}
                  onChange={(e) => setFormData({ ...formData, activityLevel: e.target.value as any })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="sedentary">Sedentary (desk job)</option>
                  <option value="light">Light exercise (1-3 days/week)</option>
                  <option value="moderate">Moderate exercise (3-5 days/week)</option>
                  <option value="active">Active (6-7 days/week)</option>
                  <option value="very_active">Very active (2x/day)</option>
                </select>
              </div>
            </div>
            
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold py-3 px-6 rounded-lg hover:from-orange-600 hover:to-red-600 transition duration-200"
            >
              Create Profile
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          Welcome back, {userProfile?.name}! 🙏
        </h2>
        <p className="text-gray-600">
          Let's continue your healthy Andhra diet journey. Stay consistent and achieve your goals!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Current Weight</p>
              <p className="text-2xl font-bold text-gray-900">{userProfile?.weight} kg</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <Scale className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Target Weight</p>
              <p className="text-2xl font-bold text-gray-900">{userProfile?.targetWeight} kg</p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <Target className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">To Lose</p>
              <p className="text-2xl font-bold text-orange-600">{weightToLose.toFixed(1)} kg</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-full">
              <TrendingDown className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Daily Calories</p>
              <p className="text-2xl font-bold text-gray-900">{userProfile?.dailyCalorieGoal}</p>
            </div>
            <div className="bg-red-100 p-3 rounded-full">
              <Activity className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Health Metrics</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">BMI</span>
              <span className={`font-semibold ${
                parseFloat(bmi) < 18.5 ? 'text-blue-600' :
                parseFloat(bmi) < 25 ? 'text-green-600' :
                parseFloat(bmi) < 30 ? 'text-orange-600' : 'text-red-600'
              }`}>{bmi}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">BMI Category</span>
              <span className="font-semibold text-gray-800">
                {parseFloat(bmi) < 18.5 ? 'Underweight' :
                 parseFloat(bmi) < 25 ? 'Normal' :
                 parseFloat(bmi) < 30 ? 'Overweight' : 'Obese'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Activity Level</span>
              <span className="font-semibold text-gray-800 capitalize">
                {userProfile?.activityLevel.replace('_', ' ')}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Quick Tips</h3>
            <span className="text-2xl">🌟</span>
          </div>
          <ul className="space-y-3 text-sm text-gray-600">
            <li className="flex items-start space-x-2">
              <span className="text-green-500 mt-1">•</span>
              <span>Start your day with pesarattu for high protein</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-green-500 mt-1">•</span>
              <span>Include fiber-rich vegetables in every meal</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-green-500 mt-1">•</span>
              <span>Use minimal oil and prefer steaming/boiling</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-green-500 mt-1">•</span>
              <span>Drink plenty of water and have herbal teas</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="text-center">
        <button
          onClick={() => setShowProfileForm(true)}
          className="text-orange-600 hover:text-orange-700 font-medium transition duration-200"
        >
          Update Profile
        </button>
      </div>
    </div>
  );
};