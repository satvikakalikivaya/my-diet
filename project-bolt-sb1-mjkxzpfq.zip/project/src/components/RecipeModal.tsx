import React from 'react';
import { X, Clock, Users, ChefHat } from 'lucide-react';
import { Recipe } from '../types';

interface RecipeModalProps {
  recipe: Recipe;
  isOpen: boolean;
  onClose: () => void;
}

export const RecipeModal: React.FC<RecipeModalProps> = ({ recipe, isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{recipe.name}</h2>
            {recipe.nameInTelugu && (
              <p className="text-lg text-orange-600 font-medium">{recipe.nameInTelugu}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition duration-200"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Total Time</p>
                <p className="font-semibold">{recipe.prepTime + recipe.cookTime} mins</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Servings</p>
                <p className="font-semibold">{recipe.servings}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <ChefHat className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Category</p>
                <p className="font-semibold capitalize">{recipe.category}</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-semibold text-gray-800 mb-3">Nutritional Information</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{recipe.calories}</p>
                <p className="text-sm text-gray-600">Calories</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{recipe.protein}g</p>
                <p className="text-sm text-gray-600">Protein</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{recipe.carbs}g</p>
                <p className="text-sm text-gray-600">Carbs</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600">{recipe.fat}g</p>
                <p className="text-sm text-gray-600">Fat</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">{recipe.fiber}g</p>
                <p className="text-sm text-gray-600">Fiber</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-3">Ingredients</h3>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span className="text-gray-700">{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-3">Instructions</h3>
            <ol className="space-y-3">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="flex space-x-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-orange-500 text-white text-sm font-semibold rounded-full flex items-center justify-center">
                    {index + 1}
                  </span>
                  <span className="text-gray-700 leading-relaxed">{instruction}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="bg-green-50 rounded-lg p-4">
            <h3 className="font-semibold text-green-800 mb-2">Health Benefits</h3>
            <ul className="space-y-1 text-sm text-green-700">
              {recipe.weightLossFriendly && (
                <li>• Supports healthy weight loss</li>
              )}
              {recipe.isHealthyVersion && (
                <li>• Modified for better nutrition</li>
              )}
              <li>• High in fiber for better digestion</li>
              <li>• Traditional Andhra flavors with modern health benefits</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};