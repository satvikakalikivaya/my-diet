export interface Recipe {
  id: string;
  name: string;
  nameInTelugu?: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  ingredients: string[];
  instructions: string[];
  prepTime: number;
  cookTime: number;
  servings: number;
  isHealthyVersion: boolean;
  affordabilityScore: number; // 1-5, 5 being most affordable
  weightLossFriendly: boolean;
}

export interface MealPlan {
  id: string;
  date: string;
  breakfast: Recipe;
  lunch: Recipe;
  dinner: Recipe;
  snacks: Recipe[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
}

export interface UserProfile {
  name: string;
  age: number;
  weight: number;
  height: number;
  targetWeight: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  dailyCalorieGoal: number;
}

export interface WeightEntry {
  date: string;
  weight: number;
}